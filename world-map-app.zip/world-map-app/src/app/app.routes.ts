import { Routes } from '@angular/router';
import { MapComponent } from './map/map.component';  // Import the map component


export const routes: Routes = [
  { path: '', component: MapComponent }  // Default route to show the map component
];

