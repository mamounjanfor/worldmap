import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MapComponent } from './map/map.component';  // Import the MapComponent



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MapComponent],  // Add the MapComponent to the imports array
  
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'world-map-app';
}
