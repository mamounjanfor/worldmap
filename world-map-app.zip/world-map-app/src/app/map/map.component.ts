import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { WorldbankApiService } from '../worldbank-api.service';

@Component({
  selector: 'app-map',
  standalone: true,
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
  countryInfo: any;

  countryCodeMap: { [key: string]: string } = {
    // Standard mappings for major countries
    'us': 'USA',  // United States
    'United_States_lower_48': 'USA',  // United States mainland
    'fr': 'FRA',  // France
    'France_mainland': 'FRA',  // France mainland
    'it': 'ITA',  // Italy
    'Italy_mainland': 'ITA',  // Italy mainland
    'es': 'ESP',  // Spain
    'Spain_mainland': 'ESP',  // Spain mainland
    'ma': 'MAR',  // Morocco
    'Morocco_mainland': 'MAR',  // Morocco mainland
    'de': 'DEU',  // Germany
    'cn': 'CHN',  // China
    'ru': 'RUS',  // Russia
    'gb': 'GBR',  // United Kingdom
    'jp': 'JPN',  // Japan
    'ca': 'CAN',  // Canada
    'au': 'AUS',  // Australia
    'br': 'BRA',  // Brazil
    'in': 'IND',  // India
    'Australia_mainland': 'AUS',  // Australia mainland
    'Australia_Tasmania': 'AUS',  // Australia Tasmania
    // Non-standard IDs from extracted logs
    'sd': 'SDN',  // Sudan
    'ss': 'SSD',  // South Sudan
    'ge-': 'GEO',  // Georgia
    'xa-': 'NAM',  // Namibia
    'xo-': 'OMN',  // Oman
    'pe': 'PER',  // Peru
    'bf': 'BFA',  // Burkina Faso
    'ly': 'LBY',  // Libya
    'by': 'BLR',  // Belarus
    'pk-': 'PAK',  // Pakistan
    'xj': 'JOR',  // Jordan
    'Indonesia_New_Guinea': 'IDN',  // Indonesia
    'Indonesia_West_Timor': 'IDN',  // Indonesia
    'Indonesia_Kalimantan': 'IDN',  // Indonesia
    'Indonesia_Sulawesi': 'IDN',  // Indonesia
    'Indonesia_Java': 'IDN',  // Indonesia
    'Indonesia_Sumatra': 'IDN',  // Indonesia
    'Yemen_Socotra': 'YEM',  // Yemen
    'Yemen_mainland': 'YEM',  // Yemen mainland
    'Madagascar_island': 'MDG',  // Madagascar
    'Madagascar_Nosy_Be': 'MDG',  // Madagascar
    'Madagascar_Nosy_Boraha': 'MDG',  // Madagascar
    'rs-': 'SRB',  // Serbia
    'xk-': 'XKX',  // Kosovo
    'ci': 'CIV',  // Ivory Coast
    'dz': 'DZA',  // Algeria
    'ch': 'CHE',  // Switzerland
    'cm': 'CMR',  // Cameroon
    'mk': 'MKD',  // North Macedonia
    'bw': 'BWA',  // Botswana
    'ke': 'KEN',  // Kenya
    'jo': 'JOR',  // Jordan
    'Mexico_mainland': 'MEX',  // Mexico
    'United_Arab_Emirates_Abu_al_Abyad': 'ARE',  // UAE
    'United_Arab_Emirates_mainland': 'ARE',  // UAE
    'Belize_Blackbird_Cay': 'BLZ',  // Belize
    'Belize_mainland': 'BLZ',  // Belize
    'Brazil_mainland': 'BRA',  // Brazil
    'Brazil_Marajo': 'BRA',  // Brazil
    'Sierra_Leone_Sherbro': 'SLE',  // Sierra Leone
    'Sierra_Leone_mainland': 'SLE',  // Sierra Leone
    'ml': 'MLI',  // Mali
    'cd': 'COD',  // Democratic Republic of the Congo
    'Italy_Pantelleria': 'ITA',  // Italy
    'Italy_Sardinia': 'ITA',  // Italy
    'Italy_Elba': 'ITA',  // Italy
    'Italy_Sicily': 'ITA',  // Italy
    'so-': 'SOM',  // Somalia
    'xs': 'SOM',  // Somalia
    'af': 'AFG',  // Afghanistan
    'Bangladesh_mainland': 'BGD',  // Bangladesh
    'Dominican_Republic_Hispaniola': 'DOM',  // Dominican Republic
    'Dominican_Republic_Isla_Saona': 'DOM',  // Dominican Republic
    'Guinea-Bissau_mainland': 'GNB',  // Guinea-Bissau
    'gh': 'GHA',  // Ghana
    'at': 'AUT',  // Austria
    'Sweden_mainland': 'SWE',  // Sweden
    'Turkey_Eastern_Thrace': 'TUR',  // Turkey
    'Turkey_Anatolia': 'TUR',  // Turkey
    'ug': 'UGA',  // Uganda
    'Mozambique_mainland': 'MOZ',  // Mozambique
    'Japan_Kyushu': 'JPN',  // Japan
    'Japan_Honshu': 'JPN',  // Japan
    'Japan_Shikoku': 'JPN',  // Japan
    'Japan_Hokkaido': 'JPN',  // Japan
    'New_Zealand_Stewart_Island': 'NZL',  // New Zealand
    'New_Zealand_South_Island': 'NZL',  // New Zealand
    'New_Zealand_North_Island': 'NZL',  // New Zealand
    'Cuba_island': 'CUB',  // Cuba
    'Venezuela_mainland': 'VEN',  // Venezuela
    'Portugal_mainland': 'PRT',  // Portugal
    'co': 'COL',  // Colombia
    'Mauritania_mainland': 'MRT',  // Mauritania
    'Angola_Cabinda': 'AGO',  // Angola
    // 'Germany_mainland': 'DEU',  // Germany (duplicate entry removed)
    'Thailand_mainland': 'THA',  // Thailand
    'Papua_New_Guinea_island': 'PNG',  // Papua New Guinea
    'Greenland_island': 'GRL',  // Greenland
    'Denmark_mainland': 'DNK',  // Denmark
    'lv': 'LVA',  // Latvia
    'ro': 'ROU',  // Romania
    'zm': 'ZMB',  // Zambia
    'Myanmar_mainland': 'MMR',  // Myanmar
    'et': 'ETH',  // Ethiopia
    'gt': 'GTM',  // Guatemala
    'sr': 'SUR',  // Suriname
    'cz': 'CZE',  // Czech Republic
    'td': 'TCD',  // Chad
    'al': 'ALB',  // Albania
    'sy': 'SYR',  // Syria
    'kg': 'KGZ',  // Kyrgyzstan
    'Oman_Musandam': 'OMN',  // Oman
    'Oman_Masirah': 'OMN',  // Oman
    'Panama_mainland': 'PAN',  // Panama
    'Argentina_Tierra_del_Fuego': 'ARG',  // Argentina
    'United_Kingdom_Northern_Ireland': 'GBR',  // United Kingdom
    'py': 'PRY',  // Paraguay
    'Nigeria_mainland': 'NGA',  // Nigeria
    'Tunisia_mainland': 'TUN',  // Tunisia
    'pl': 'POL',  // Poland
    'na': 'NAM',  // Namibia
    'za': 'ZAF',  // South Africa
    'eg': 'EGY',  // Egypt
    'Tanzania_mainland': 'TZA',  // Tanzania
    'Saudi_Arabia_mainland': 'SAU',  // Saudi Arabia
    'Vietnam_mainland': 'VNM',  // Vietnam
    'ba': 'BIH',  // Bosnia and Herzegovina
    'India_mainland': 'IND',  // India
    'Canada_mainland': 'CAN',  // Canada
    'Germany_mainland': 'DEU',  // Germany
    'China_Hainan': 'CHN',  // China
    'mo-': 'MAC',  // Macau
    'gf': 'GUF',  // French Guiana
    'Portugal_Madeira': 'PRT',  // Portugal
    'lb-': 'LBN',  // Lebanon
    'sz-': 'SWZ',  // Eswatini
    // Add more as needed
  };
  
  constructor(
    private worldbankService: WorldbankApiService,
    @Inject(PLATFORM_ID) private platformId: any
  ) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.loadSVGMap();
    }
  }

  // Method to load the SVG map
  loadSVGMap(): void {
    const svgContainer = document.getElementById('svgMapContainer');
  
    fetch('assets/BlankMap-World.svg')
      .then(response => response.text())
      .then(svgContent => {
        if (svgContainer) {
          svgContainer.innerHTML = svgContent;
  
          const countryPaths = svgContainer.getElementsByTagName('path');
          Array.from(countryPaths).forEach(path => {
            // Add click event listener
            path.addEventListener('click', () => {
              this.onCountryClick(path.id);
            });
  
            // Add hover effect (mouseenter and mouseleave)
            path.addEventListener('mouseenter', () => {
              path.style.fill = '#d1e0ff';  // Light blue when hovered
              path.style.stroke = '#333';   // Darker stroke on hover
              path.style.strokeWidth = '1';
            });
  
            path.addEventListener('mouseleave', () => {
              path.style.fill = '';         // Reset to default fill color
              path.style.stroke = '';       // Reset to default stroke
              path.style.strokeWidth = '';  // Reset to default stroke width
            });
          });
        }
      })
      .catch(err => console.error('Error loading SVG:', err));
  }
  

  // Method 2: Trigger API call when country is clicked
  onCountryClick(countryCode: string): void {
    const apiCountryCode = this.getMappedCountryCode(countryCode);

    if (apiCountryCode) {
      this.worldbankService.getCountryInfo(apiCountryCode.toLowerCase()).subscribe(
        (data) => {
          if (data && data[1] && data[1].length > 0) {
            this.countryInfo = data[1][0];  // Store country info
          } else {
            console.error(`No data found for country code: ${apiCountryCode}`);
          }
        },
        (error) => {
          console.error('Error fetching country data:', error);
        }
      );
    } else {
      console.error(`Country code not recognized: ${countryCode}`);
    }
  }

  // Map country codes for SVG to API format
  getMappedCountryCode(svgCountryCode: string): string {
    return this.countryCodeMap[svgCountryCode] || svgCountryCode.replace(/_.*$/, '');
  }
}
